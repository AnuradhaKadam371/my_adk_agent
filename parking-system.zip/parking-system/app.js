const FLOORS = 2;
const SLOTS_PER_FLOOR = 8;
const parkingArea = document.getElementById('parkingArea');
const sidebar = document.querySelector('.sidebar .spawn-area');
let slots = [];

// Build UI
function buildUI(){
    for(let f=1; f<=FLOORS; f++){
        const floorDiv = document.createElement('div');
        floorDiv.className = 'floor';

        const label = document.createElement('div');
        label.className = 'floor-label';
        label.textContent = `Floor ${f}`;
        floorDiv.appendChild(label);

        for(let s=1; s<=SLOTS_PER_FLOOR; s++){
            const slot = document.createElement('div');
            slot.className='slot';
            slot.dataset.floor=f;
            slot.dataset.index=s;
            slot.innerHTML=`<div class="meta">Slot ${s}<br><small>Empty</small></div>`;
            floorDiv.appendChild(slot);

            const slotObj = {el:slot,floor:f,index:s,occupied:false,info:null,carEl:null};
            slots.push(slotObj);

            slot.addEventListener('click',()=>onSlotClick(slotObj));
        }

        parkingArea.appendChild(floorDiv);

        // Add road after every floor
        const road = document.createElement('div');
        road.className='road';
        parkingArea.appendChild(road);
    }
}

buildUI();

// Modal logic
const modalBackdrop = document.getElementById('modalBackdrop');
const modal = document.getElementById('modal');
let modalCallback=null;

function showModal({title,content,buttons,onAction}){
    modalCallback=onAction;
    let html=`<h3>${title}</h3><div>${content}</div><div class="buttons">`;
    buttons.forEach(b=>html+=`<button class="btn ${b.style==='primary'?'primary':'secondary'}" data-action="${b.action}">${b.label}</button>`);
    html+='</div>';
    modal.innerHTML=html;
    modalBackdrop.classList.add('show');
    modal.querySelectorAll('button').forEach(btn=>{
        btn.addEventListener('click',()=>{
            const action=btn.dataset.action;
            if(modalCallback){
                const res=modalCallback(action);
                if(res===false) return;
            }
            if(action==='close') closeModal();
        });
    });
}

function closeModal(){ 
    modalBackdrop.classList.remove('show'); 
    modal.innerHTML=''; 
    modalCallback=null; 
}

function onSlotClick(slotObj){
    if(slotObj.occupied){
        showModal({
            title:`Slot ${slotObj.index} (Floor ${slotObj.floor})`,
            content:`<div><strong>${slotObj.info.name}</strong><br>Vehicle: ${slotObj.info.vehicle}</div>`,
            buttons:[
                {label:'Close',action:'close',style:'secondary'},
                {label:'Checkout',action:'checkout',style:'primary'}
            ],
            onAction:(action)=>{ if(action==='checkout') checkoutSlot(slotObj);}
        });
        return;
    }
    showModal({
        title:`Park at Slot ${slotObj.index} (Floor ${slotObj.floor})`,
        content:`<label>Name</label><input id="inpName"/><label>Vehicle</label><input id="inpVehicle"/>`,
        buttons:[
            {label:'Cancel',action:'close',style:'secondary'},
            {label:'OK',action:'ok',style:'primary'}
        ],
        onAction:(action)=>{
            if(action==='ok'){
                const name=document.getElementById('inpName').value.trim();
                const vehicle=document.getElementById('inpVehicle').value.trim();
                if(!name||!vehicle){ alert('Enter all details'); return false;}
                parkCar(slotObj,{name,vehicle});
            }
        }
    });
}

// Park car with realistic animation (fixed for scrolling and sidebar gap)
function parkCar(slotObj, info){
 const mainContainer = document.querySelector('.main'); // your scrollable div

    const car=document.createElement('div');
    car.className='car';
    document.body.appendChild(car);

    slotObj.occupied=true;
    slotObj.info=info;
    slotObj.carEl=car;
    slotObj.el.classList.add('occupied');
    slotObj.el.querySelector('.meta').innerHTML=`Slot ${slotObj.index}<br><small>${info.vehicle}</small>`;

    const slotRect = slotObj.el.getBoundingClientRect();
    const floorIndex = slotObj.floor - 1;
    const road = document.querySelectorAll('.road')[floorIndex];
    const roadRect = road.getBoundingClientRect();

    // Get scroll offsets
    const scrollTop = window.scrollY;
    const scrollLeft = window.scrollX;

    // Start at left edge of the road (next to sidebar)
    const sidebarRect = sidebar.getBoundingClientRect();
    car.style.left = (sidebarRect.right + scrollLeft) + 'px';
    car.style.top = (roadRect.top + scrollTop) + 'px';

    setTimeout(()=>{
        // Move horizontally along road
        car.style.left = (slotRect.left + scrollLeft) + 'px';
    },50);

    setTimeout(()=>{
        // Move vertically into slot
        car.style.top = (slotRect.top + scrollTop) + 'px';
    }, 800);

    car.addEventListener('click',()=> onSlotClick(slotObj));
    closeModal();
}

// Checkout with realistic exit (fixed for scrolling)
function checkoutSlot(slotObj){
    const car = slotObj.carEl;
    const slotRect = slotObj.el.getBoundingClientRect();
    const floorIndex = slotObj.floor - 1;
    const road = document.querySelectorAll('.road')[floorIndex];
    const roadRect = road.getBoundingClientRect();

    const scrollTop = window.scrollY;
    const scrollLeft = window.scrollX;

    // Move vertically from slot to road
    car.style.top = (roadRect.top + scrollTop) + 'px';

    setTimeout(()=>{
        // Move right along the road to exit
        car.style.left = (window.innerWidth + scrollLeft) + 'px';
    },500);

    car.addEventListener('transitionend', ()=>{
        car.remove();
        slotObj.occupied=false;
        slotObj.info=null;
        slotObj.carEl=null;
        slotObj.el.classList.remove('occupied');
        slotObj.el.querySelector('.meta').innerHTML=`Slot ${slotObj.index}<br><small>Empty</small>`;
        closeModal();
    }, {once:true});

    closeModal();
}

// Sidebar buttons
function showReport(){ alert('Show Reports'); }
function showRules(){ alert('Show Rules'); }
function showMain(){ alert('Main Dashboard'); }
